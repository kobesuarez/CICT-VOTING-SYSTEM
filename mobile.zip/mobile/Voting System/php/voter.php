<?php
include 'connection.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';


$length = 10;
$keyspace = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

$str = '';
$max = mb_strlen($keyspace, '8bit') - 1;
for ($i = 0; $i < $length; ++$i) {
    $str .= $keyspace[random_int(0, $max)];
}



session_start();
if (!isset($_SESSION['adminname']) || !isset($_SESSION['adminpass'])) {
    header('Location: admin.php');
    exit;
}
$year1 = "SELECT * from studentlist WHERE studentyear = '1st Year'";
$year2 = "SELECT * from studentlist WHERE studentyear = '2nd Year'";
$year3 = "SELECT * from studentlist WHERE studentyear = '3rd Year'";
$year4 = "SELECT * from studentlist WHERE studentyear = '4th Year'";
if ($result = mysqli_query($conn, $year1)) {
    $year1row = mysqli_num_rows($result);
}
if ($result = mysqli_query($conn, $year2)) {
    $year2row = mysqli_num_rows($result);
}
if ($result = mysqli_query($conn, $year3)) {
    $year3row = mysqli_num_rows($result);
}
if ($result = mysqli_query($conn, $year4)) {
    $year4row = mysqli_num_rows($result);
}




?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/Voting System/stylesheets/voter.css">
    <link rel="shortcut icon" href="/src/cict.png" type="image/x-icon/">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <title>Voter's List
    </title>
</head>

<body>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <div class="topnav w-100 py-0 px-0">
        <div class="row pt-2 mt-3 g-0">
            <div class="col-1 d-flex justify-content-end">
                <img src="/src//cict.png" class="img">
            </div>
            <div class="col-9 px-0">
                <h2>Taguig City University</h2>
                <h4>College of Information Communication and Technology Admin Portal</h4>
            </div>
            <div class="col-2 d-flex align-items-center justify-content-center px-0">
                <div class="col-2">
                    <h3><a href="logout.php" style="text-decoration: none; color: black">Logout</a></h3>
                </div>
            </div>
        </div>
        <div class="row flex-row g-0">
            <ul class="d-flex justify-content-around my-0 mx-0">
                <li><a href="dashboard.php" style="text-decoration: none; color: black">Dashboard</a></li>
                <li class="act"><button class="actbtn">Voter's List</button></li>
                <li><a href="candidate.php" style="text-decoration: none; color: black">Candidates</a></li>
                <li><a href="schedule.php" style="text-decoration: none; color: black">Other</a></li>
            </ul>
        </div>
    </div>

    <div class="row g-0 d-flex justify-content-center">
        <div class="col-7 px-0">
            <div class="list py-3 px-3 my-3 mx-3">
                <div class="toplist">
                    <div class="row">
                        <div class="col d-flex justify-content-end">
                            <button type="button" class="btn btn-primary btn-sm mx-2 px-5 " data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                Register
                            </button>
                        </div>
                    </div>
                </div>
                <div class="tablelist mx-2 my-3 table-responsive">
                    <table class="table table-hover table-striped">
                        <thead>
                            <tr>
                                <th>Student Name</th>
                                <th>Student Number</th>
                                <th>Email</th>
                                <th>Year</th>
                                <th>Section</th>
                                <th>Contact Number</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            include 'connection.php';
                            $filltable = "SELECT * FROM studentlist";
                            $fill = mysqli_query($conn, $filltable);
                            while ($getrow = mysqli_fetch_array($fill)) {
                                echo '
                                <tr>
                                    <td>' . $getrow["studentname"] . '</td>
                                    <td>' . $getrow["studentnumber"] . '</td>
                                    <td>' . $getrow["studentemail"] . '</td>
                                    <td>' . $getrow["studentyear"] . '</td>
                                    <td>' . $getrow["studentsection"] . '</td>
                                    <td>' . $getrow["studentcontactnumber"] . '</td>
                                </tr>
                                ';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <?php
                if (isset($_POST['signup'])) {

                    if (
                        empty($_POST['fname']) || empty($_POST['sno']) || empty($_POST['smail']) ||
                        empty($_POST['syear']) || empty($_POST['scon'])
                        || empty($_POST['section'])
                    ) {
                        echo '<p class = "text-danger mb-0"><b>Fields must not be blanks!</b></p>';
                    } else {
                        $sname = $_POST['fname'];
                        $sno = $_POST['sno'];
                        $smail = $_POST['smail'];
                        $syear = $_POST['syear'];
                        $scourse = $_POST['scourse'];
                        $section = $_POST['section'];
                        $scno = $_POST['scon'];
                        $votingstatus = 0;
                        $sname = mysqli_real_escape_string($conn, $sname);
                        $sno = mysqli_real_escape_string($conn, $sno);
                        $smail = mysqli_real_escape_string($conn, $smail);
                        $syear = mysqli_real_escape_string($conn, $syear);
                        $section = mysqli_real_escape_string($conn, $section);
                        $scno = mysqli_real_escape_string($conn, $scno);
                        try {
                            $insertquery = "insert into studentlist(studentname, studentnumber, studentemail, studentcourse, studentyear, studentsection, studentcontactnumber, studentpassword) values ('$sname', '$sno', '$smail', '$scourse','$syear', '$section', '$scno', '$str')";
                            $performquery = mysqli_query($conn, $insertquery);
                            $vinsertquery = "insert into studentvote(sno, votedpres, votedvpresi, votedvprese, votedgs, votedds, votedtrea, votedaudi, votedpiom, votedpiof, vstatus) values ('$sno', 0, 0, 0, 0, 0, 0,0,0, 0, 'Not Voted')";
                            $vperformquery = mysqli_query($conn, $vinsertquery);


                            $mail = new PHPMailer(true);

                            try {
                                $mail->isSMTP();
                                $mail->Host       = 'smtp.gmail.com';
                                $mail->SMTPAuth   = true;
                                $mail->Username   = 'kobe.suarez18@gmail.com';
                                $mail->Password   = 'ookrlbxnpfpbfwza';
                                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
                                $mail->Port       = 465;

                                //Recipients
                                $mail->setFrom('kobe.suarez18@gmail.com');
                                $mail->addAddress($_POST['smail']);

                                //Content
                                $mail->isHTML(true);
                                $mail->Subject = 'Account for CICT Voting Website';
                                $mail->Body    = 'Your username will be: <b>' . $sno . '</b></=> And your Password is: <b>' . $str . '</b>. </br><a href="http://localhost:3000/login.php/" >Click here</a> to Login your account';

                                $mail->send();
                                echo '<p class = "text-success mb-0"><b>Student registered!</b></p>';
                            } catch (Exception $e) {
                                echo "<p class = 'text-danger mb-0'><b>Message could not be sent. Mailer Error: {$mail->ErrorInfo}</b></p>";
                            }
                        } catch (exception $e) {
                            echo '<p class = "text-danger mb-0"><b>Student already exist!</b></p>';
                        }
                    }
                }
                ?>
            </div>
        </div>
        <div class="col-2 my-3 px-0">
            <div class="vgraph">
                <canvas id="yearlevelchart" width="45%" height="100%"></canvas>
                <script>
                    const year1 = <?php echo json_encode($year1row);  ?>;
                    const year2 = <?php echo json_encode($year2row);  ?>;
                    const year3 = <?php echo json_encode($year3row);  ?>;
                    const year4 = <?php echo json_encode($year4row);  ?>;

                    const data = {
                        labels: ['1st Year', '2nd Year', '3rd Year', '4th Year'],
                        datasets: [{
                            label: 'Year Level',
                            data: [year1, year2, year3, year4],
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.2)',
                                'rgba(255, 159, 64, 0.2)',
                                'rgba(255, 205, 86, 0.2)',
                                'rgba(75, 192, 192, 0.2)'

                            ],
                            borderColor: [
                                'rgb(255, 99, 132)',
                                'rgb(255, 159, 64)',
                                'rgb(255, 205, 86)',
                                'rgb(75, 192, 192)',
                                'rgb(54, 162, 235)'
                            ],
                            borderWidth: 1
                        }]
                    };
                    const config = {
                        type: 'bar',
                        data: data,
                        options: {
                            scales: {
                                y: {
                                    beginAtZero: true
                                }
                            }
                        },
                    };
                    const cookiechart = new Chart(document.getElementById('yearlevelchart'), config);
                </script>
            </div>
        </div>
    </div>
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <form method="post" enctype="multipart/form-data">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="modal-title fs-5" id="staticBackdropLabel">Register Student</h2>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div>
                            <label class="form-label">Full Name</label>
                            <input type="text" class="form-control" name="fname" required>

                            <label class="form-label">Contact Number</label>
                            <input type="text" class="form-control" name="scon" required>

                            <label class="form-label">Student Number</label>
                            <input type="text" class="form-control" name="sno" required>

                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" name="smail" required placeholder="example@gmail.com">

                            <label class="form-label">Year level</label>
                            <select class="form-select" name="syear" required>
                                <option value="1st Year">1st Year</option>
                                <option value="2nd Year">2nd Year</option>
                                <option value="3rd Year">3rd Year</option>
                                <option value="4th Year">4th Year</option>
                            </select>

                            <label class="form-label">Section</label>
                            <input type="text" class="form-control" name="section" required>

                            <label class="form-label">Course</label>
                            <select class="form-select" name="scourse" required>
                                <option value="Bachelor of Science in Computer Science">Bachelor of Science in Computer Science</option>
                                <option value="Bachelor of Science in Information System">Bachelor of Science in Information System</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="submit" name="signup" class="btn btn-primary" data-bs-dismiss="modal"></input></br>
                        <button data-bs-dismiss="modal" class="btn btn-danger">Cancel</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

</body>

</html>