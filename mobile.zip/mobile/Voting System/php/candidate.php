<?php
include 'connection.php';
session_start();
if (!isset($_SESSION['adminname']) || !isset($_SESSION['adminpass'])) {
    header('Location: admin.php');
    exit;
}
$selectquery = "select MAX(votes) from president";
$res = mysqli_query($conn, $selectquery);
$data = mysqli_fetch_array($res);
$cpresvote = $data['MAX(votes)'];

$selectquery = "select MAX(votes) from vpresi";
$res = mysqli_query($conn, $selectquery);
$data = mysqli_fetch_array($res);
$cvpresivote = $data['MAX(votes)'];

$selectquery = "select MAX(votes) from vprese";
$res = mysqli_query($conn, $selectquery);
$data = mysqli_fetch_array($res);
$cvpresevote = $data['MAX(votes)'];

$selectquery = "select MAX(votes) from gensec";
$res = mysqli_query($conn, $selectquery);
$data = mysqli_fetch_array($res);
$cgensecvote = $data['MAX(votes)'];

$selectquery = "select MAX(votes) from depsec";
$res = mysqli_query($conn, $selectquery);
$data = mysqli_fetch_array($res);
$cdepsecvote = $data['MAX(votes)'];

$selectquery = "select MAX(votes) from trea";
$res = mysqli_query($conn, $selectquery);
$data = mysqli_fetch_array($res);
$ctreavote = $data['MAX(votes)'];

$selectquery = "select MAX(votes) from audi";
$res = mysqli_query($conn, $selectquery);
$data = mysqli_fetch_array($res);
$caudivote = $data['MAX(votes)'];

$selectquery = "select MAX(votes) from piom";
$res = mysqli_query($conn, $selectquery);
$data = mysqli_fetch_array($res);
$cpiomvote = $data['MAX(votes)'];

$selectquery = "select MAX(votes) from piof";
$res = mysqli_query($conn, $selectquery);
$data = mysqli_fetch_array($res);
$cpiofvote = $data['MAX(votes)'];

$partylistquery = "SELECT DISTINCT partylist FROM listpartylist";
$result = mysqli_query($conn, $partylistquery);
if ($result) {
    $options = mysqli_fetch_all($result, MYSQLI_ASSOC);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/Voting System/stylesheets/candidate.css">
    <link rel="shortcut icon" href="/src/cict.png" type="image/x-icon/">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <title>Candidate's List</title>
</head>
<style>
    :required::after {
        content: "*";
        color: red;
    }
</style>

<body>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        function addlist() {
            var plist = document.getElementById("addpartylist").value;
            if (confirm("Are you sure to add " + plist + "?")) {
                var addlist = document.getElementById("list"),
                    textValue = document.getElementById("addpartylist").value,
                    newPartylist = document.createElement("OPTION"),
                    newPartylistv = document.createTextNode(textValue);

                newPartylist.appendChild(newPartylistv);
                addlist.insertBefore(newPartylist, addlist.lastChild);
                document.getElementById("addpartylist").value = "";
            }
        }
    </script>
    <div class="topnav w-100 py-0 px-0">
        <div class="row pt-2 mt-3 g-0">
            <div class="col-1 d-flex justify-content-end">
                <img src="/src//cict.png" class="img">
            </div>
            <div class="col-9 px-0">
                <h2>Taguig City University</h2>
                <h4>College of Information Communication and Technology Admin Portal</h4>
            </div>
            <div class="col-2 d-flex align-items-center justify-content-center px-0">
                <div class="col-2">
                    <h3><a href="logout.php" style="text-decoration: none; color: black">Logout</a></h3>
                </div>
            </div>
        </div>
        <div class="row flex-row g-0">
            <ul class="d-flex justify-content-around my-0 mx-0">
                <li><a href="dashboard.php" style="text-decoration: none; color: black">Dashboard</a></li>
                <li><a href="voter.php" style="text-decoration: none; color: black">Voter's List</a></li>
                <li class="act"><button class="actbtn">Candidates</button></li>
                <li><a href="schedule.php" style="text-decoration: none; color: black">Other</a></li>
            </ul>
        </div>
    </div>

    </div>
    <div class="row g-0 d-flex justify-content-center">
        <div class="col-7">
            <div class="list">
                <div class="toplist">
                    <div class="row">
                        <div class="col d-flex justify-content-end">
                            <button type="button" class="btn btn-primary btn-sm mx-2 px-5 " data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                Add
                            </button>
                        </div>
                    </div>
                </div>

                <div class="tablelist table-responsive">
                    <table class="table table-hover table-striped">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Student Number</th>
                                <th>Age</th>
                                <th>Gender</th>
                                <th>Course</th>
                                <th>Position</th>
                                <th>Partylist</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            include 'connection.php';
                            $filltable = "SELECT * FROM candidate";
                            $fill = mysqli_query($conn, $filltable);
                            while ($getrow = mysqli_fetch_array($fill)) {
                                echo '
                                <tr>
                                    <td>' . $getrow["candidatename"] . '</td>
                                    <td>' . $getrow["candidatestudentnumber"] . '</td>
                                    <td>' . $getrow["candidateage"] . '</td>
                                    <td>' . $getrow["candidategender"] . '</td>
                                    <td>' . $getrow["candidatecourse"] . '</td>
                                    <td>' . $getrow["candidateposition"] . '</td>
                                    <td>' . $getrow["candidatepartylist"] . '</td>
                                </tr>
                                ';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <?php
                if (isset($_POST['submit'])) {
                    if (
                        empty($_POST['fname']) || empty($_POST['lname']) || empty($_POST['cno'])
                        || empty($_POST['cage']) || empty($_POST['my_file'])
                    ) {
                        $cname = $_POST['fname'] . ' ' . $_POST['mname'] . ' ' . $_POST['lname'];
                        $cno = $_POST['cno'];
                        $cage = $_POST['cage'];
                        $cgender = $_POST['cgender'];
                        $course = $_POST['course'];
                        $cposition = $_POST['cpositions'];
                        $cpartylist = $_POST['cpartylist'];
                        $votingstatus = 0;
                        $cname = mysqli_real_escape_string($conn, $cname);
                        $cno = mysqli_real_escape_string($conn, $cno);
                        $cage = mysqli_real_escape_string($conn, $cage);
                        $cgender = mysqli_real_escape_string($conn, $cgender);
                        $course = mysqli_real_escape_string($conn, $course);
                        $cposition = mysqli_real_escape_string($conn, $cposition);
                        $cpartylist = mysqli_real_escape_string($conn, $cpartylist);
                        if (($_FILES['my_file']['name'] != "")) {

                            $target_dir = "C:\Users\Acer\Documents\mobile\src\candidate\\" . $cposition . "\\" . $cno;
                            $file = $_FILES['my_file']['name'];
                            $path = pathinfo($file);
                            $ext = $path['extension'];
                            $temp_name = $_FILES['my_file']['tmp_name'];
                            $path_filename_ext = $target_dir . "." . $ext;
                            $fileurl = $cno . '.' . $ext;
                            if (!file_exists($path_filename_ext)) {
                                move_uploaded_file($temp_name, $path_filename_ext);
                            }
                        }
                        try {
                            $insertquery = "INSERT into candidate(candidatename, candidatestudentnumber, candidateage, candidategender, candidatecourse, candidateposition, candidatepartylist, candidatepicture) values ('$cname', '$cno', '$cage', '$cgender', '$course', '$cposition', '$cpartylist', '$fileurl')";
                            $performquery = mysqli_query($conn, $insertquery);
                            if ($performquery) {
                                echo '<p class = "text-success mb-0"><b>Candidate registered!</b></p>';
                            }
                        } catch (exception $e) {

                        }

                        try {
                            $insertpartylist = "INSERT INTO listpartylist(partylist) values ('$cpartylist')";
                            $listquery = mysqli_query($conn, $insertpartylist);
                        } catch (exception $e) {
                            echo '<p class = "text-danger mb-0"><b>Partylist already exist!</b></p>';
                        }
                        switch ($_POST['cpositions']) {
                            case 'President':
                                try {
                                    $insertcandidate = "INSERT into president(pres_no, pres_name, votes, partylist) values ('$cno','$cname', '0', '$cpartylist')";
                                    $inscan = mysqli_query($conn, $insertcandidate);
                                } catch (exception $e) {
                                }
                                break;
                            case 'Vice President - Internal':
                                try {
                                    $insertcandidate = "INSERT into vpresi(vpresi_no, vpresi_name, votes, partylist) values ('$cno','$cname', '0', '$cpartylist')";
                                    $inscan = mysqli_query($conn, $insertcandidate);
                                } catch (exception $e) {
                                }
                                break;
                            case 'Vice President - External':
                                try {
                                    $insertcandidate = "INSERT into vprese(vprese_no, vprese_name, votes, partylist) values ('$cno','$cname', '0', '$cpartylist')";
                                    $inscan = mysqli_query($conn, $insertcandidate);
                                } catch (exception $e) {
                                }
                                break;
                            case 'General Secretary':
                                try {
                                    $insertcandidate = "INSERT into gensec(gensec_no, gensec_name, votes, partylist) values ('$cno','$cname', '0', '$cpartylist')";
                                    $inscan = mysqli_query($conn, $insertcandidate);
                                } catch (exception $e) {
                                }
                                break;
                            case 'Deputy Secretary':
                                try {
                                    $insertcandidate = "INSERT into depsec(depsec_no, depsec_name, votes, partylist) values ('$cno','$cname', '0', '$cpartylist')";
                                    $inscan = mysqli_query($conn, $insertcandidate);
                                } catch (exception $e) {
                                }
                                break;
                            case 'Treasurer':
                                try {
                                    $insertcandidate = "INSERT into trea(trea_no, trea_name, votes, partylist) values ('$cno','$cname', '0', '$cpartylist')";
                                    $inscan = mysqli_query($conn, $insertcandidate);
                                } catch (exception $e) {
                                }

                                break;
                            case 'Auditor':
                                try {
                                    $insertcandidate = "INSERT into audi(audi_no, audi_name, votes, partylist) values ('$cno','$cname', '0', '$cpartylist')";
                                    $inscan = mysqli_query($conn, $insertcandidate);
                                } catch (exception $e) {
                                }
                                break;
                            case 'Public Information Officer - Male':
                                try {
                                    $insertcandidate = "INSERT into piom(piom_no, piom_name, votes, partylist) values ('$cno','$cname', '0', '$cpartylist')";
                                    $inscan = mysqli_query($conn, $insertcandidate);
                                } catch (exception $e) {
                                }
                                break;
                            case 'Public Information Officer - Female':
                                try {
                                    $insertcandidate = "INSERT into piof(piof_no, piof_name, votes, partylist) values ('$cno','$cname', '0', '$cpartylist')";
                                    $inscan = mysqli_query($conn, $insertcandidate);
                                } catch (exception $e) {
                                }
                                break;
                            default:
                                echo '<p class = "text-danger mb-0"><b>Candidate already registered!</b></p>';
                        }
                    } else {
                        echo '<p class = "text-danger mb-0"><b>Fields must not be blanks!</b></p>';
                    }
                }


                ?>
            </div>
        </div>
        <div class="col-4 my-3 px-1">
            <div class="vgraph">
                <canvas id="partylist" width="20%" height="20%"></canvas>
            </div>
        </div>
    </div>
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <form method="post" enctype="multipart/form-data">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="modal-title fs-5" id="staticBackdropLabel">Add Candidate</h2>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div>
                            <div class="row">
                                <div class="col-4">
                                    <label class="form-label">Last Name</label>
                                    <input type="text" class="form-control" name="lname" required>
                                </div>
                                <div class="col-4">
                                    <label class="form-label">First Name</label>
                                    <input type="text" class="form-control" name="fname" required>
                                </div>
                                <div class="col-4">
                                    <label class="form-label">Middle Name</label>
                                    <input type="text" class="form-control" name="mname" required>
                                </div>
                            </div>

                            <label class="form-label">Age</label>
                            <input type="text" class="form-control" name="cage">

                            <input type="radio" name="cgender" class="form-check-input" value="Male" required>Male
                            <input type="radio" name="cgender" class="form-check-input" style="margin-left: 15px;" value="Female" required>Female </br>

                            <label class="form-label">Student Number</label>
                            <input type="text" class="form-control" name="cno" required>

                            <label class="form-label">Course</label>
                            <select class="form-select" name="course" required>
                                <option value="Bacherlor of Science in Computer Science">Bacherlor of Science in Computer Science</option>
                                <option value="Bachelor of Science in Information System">Bachelor of Science in Information System</option>
                            </select>

                            <label class="form-label">Position</label>
                            <select class="form-select" name="cpositions" required>
                                <option value="President">President</option>
                                <option value="Vice President - Internal">Vice President - Internal</option>
                                <option value="Vice President - External">Vice President - External</option>
                                <option value="General Secretary">General Secretary</option>
                                <option value="Deputy Secretary">Deputy Secretary</option>
                                <option value="Treasurer">Treasurer</option>
                                <option value="Auditor">Auditor</option>
                                <option value="Public Information Officer - Male">Public Information Officer - Male</option>
                                <option value="Public Information Officer - Female">Public Information Officer - Female</option>
                            </select>
                            <div class="row g-0 justify-content-between">
                                <div class="col-5">
                                    <label class="form-label">Partylist</label>
                                    <select class="form-select" name="cpartylist" id="list" required>
                                        <option value="" disabled selected>Select partylist</option>
                                        <?php
                                        foreach ($options as $option) {
                                        ?>
                                            <option value="<?php echo $option['partylist']; ?>"><?php echo $option['partylist']; ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="col-4">
                                    <label class="form-label">Add Partylist</label>
                                    <input type="text" class="form-control" name="addpartylist" id="addpartylist">
                                </div>
                                <div class="col-2 d-flex align-self-end">
                                    <button type="button" class="btn btn-primary" onclick="addlist();" formnovalidate>Add Partylist</button>
                                </div>
                            </div>
                            <label class="form-label">Upload Picture</label>
                            <input class="form-control" type="file" name="my_file"accept="image/*" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="submit" name="submit" class="btn btn-primary" data-bs-dismiss="modal"></input></br>
                        <button data-bs-dismiss="modal" class="btn btn-danger">Cancel</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <script>
        const presvote = <?php echo json_encode($cpresvote);  ?>;
        const vpresivote = <?php echo json_encode($cvpresivote);  ?>;
        const vpresevote = <?php echo json_encode($cvpresevote);  ?>;
        const gensecvote = <?php echo json_encode($cgensecvote);  ?>;
        const depsecvote = <?php echo json_encode($cdepsecvote);  ?>;
        const treavote = <?php echo json_encode($ctreavote);  ?>;
        const audivote = <?php echo json_encode($caudivote);  ?>;
        const piomvote = <?php echo json_encode($cpiomvote);  ?>;
        const piofvote = <?php echo json_encode($cpiofvote);  ?>;
        const data = {
            labels: ['President', 'VP - Internal', 'VP - External', 'Gen. Sec.', 'Dep. Sec.', 'Treasurer', 'Auditor', 'PIO - Male', 'PIO - Female'],
            datasets: [{
                axis: 'y',
                label: 'Leading Votes per Position',
                data: [presvote, vpresivote, vpresevote, gensecvote, depsecvote, treavote, audivote, piomvote, piofvote],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(255, 159, 64, 0.2)',
                    'rgba(255, 205, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(93, 155, 155, 0.2)',
                    'rgba(100, 107, 099, 0.2)',
                    'rgba(239, 169, 074, 0.2)',
                    'rgba(037, 041, 074, 0.2)',
                    'rgba(214, 174, 001, 0.2)'
                ],
                borderColor: [
                    'rgb(255, 99, 132)',
                    'rgb(255, 159, 64)',
                    'rgb(255, 205, 86)',
                    'rgb(75, 192, 192)',
                    'rgb(089, 035, 033)',
                    'rgb(096, 111, 140)',
                    'rgb(193, 135, 107)',
                    'rgb(037, 041, 074)',
                    'rgb(091, 058, 041)'
                ],
                borderWidth: 1
            }]
        };
        const config = {
            type: 'bar',
            data: data,
            options: {
                indexAxis: 'y',
                scales: {
                    x: {
                        beginAtZero: true
                    }
                }
            },
        };
        const partylistbar = new Chart(document.getElementById('partylist'), config);

        function updatechart(option) {
            partylistbar.data.datasets[0].label = option.value;

            partylistbar.update();
            var plist = option.value;
            document.cookie = "picked = " + plist;
        }
    </script>
</body>


</html>