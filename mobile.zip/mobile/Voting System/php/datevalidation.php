<?php
include 'connection.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$getdate = 'SELECT * FROM setsched';
$get = mysqli_query($conn, $getdate);
$data = mysqli_fetch_array($get);
if($data != null){
    $exp_date = $data['deadline'];
    $_SESSION['duedate'] = $exp_date;
}else{
    $exp_date = null;
}
if(isset($_POST['submit'])){
    if($_POST['pass'] == $_SESSION['adminpass']){
        if(empty($_POST['setdate'])){
            echo '<script language="javascript">';
            echo 'alert("Set a date!")';
            echo '</script>';
        }else{
            if(empty($data)){
                $exp_date = $_POST['setdate'];
                $insertdate = "INSERT into setsched(deadline) VALUES ('$exp_date')";
                $ins = mysqli_query($conn, $insertdate);
                header("Location: schedule.php");
            }else{
                $upsched = "UPDATE setsched SET deadline='". $_POST['setdate'] ."' WHERE 1";
                $up = mysqli_query($conn, $upsched);
                header("Location: schedule.php");
            }
            
        }
    }else{
        echo '<script language="javascript">';
        echo 'alert("Wrong Credentials")';
        echo '</script>';
    }
    
}


?>
