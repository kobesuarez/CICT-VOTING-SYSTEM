<?php
include('checkvote.php');

include('Voting System\php\datevalidation.php');
if (!empty($exp_date)) {
    $newDate = date("m/d/y", strtotime($exp_date));
    $exp = $newDate;
    $today_date = date('m/d/y');
    $td = strtotime($today_date);
    $ed = strtotime($exp);
    if ($td <= $ed) {
        $diff = $td - $ed;
        $days = abs(floor($diff / (60 * 60 * 24)));
        $datemess = "Voting Started! Remaining days:";
        $alert = "alert alert-info";
    } else {
        $datemess = "The schedule for voting is already done!";
        $alert = "alert alert-danger";
        header("Location: stats.php");
    }
} else {
    $datemess = "Schedule to be Announce";
    $alert = "alert alert-primary";
    header("Location: Dashboard.php");
}
if (isset($_SESSION['stno'])) {
    $sno = $_SESSION['stno'];
    if ($vprese == 0) {
            if (isset($_POST['votevprese'])) {
                $id = $_POST['votevprese'];
                $votequery = "SELECT votes FROM vprese WHERE vprese_no = '$id'";
                $vote = mysqli_query($conn, $votequery);
                $data = mysqli_fetch_array($vote);
                $getvote = $data['votes'];
                $getvote = $getvote + 1;
                $updatevote = "UPDATE vprese SET votes = '$getvote' WHERE vprese_no = '$id'";
                mysqli_query($conn, $updatevote);
                $updatestudent = "UPDATE studentvote SET votedvprese = '$id' WHERE sno = '$sno'";
                mysqli_query($conn, $updatestudent);
                $getstatus = "SELECT * from studentvote WHERE sno = '$sno'";
                $res = mysqli_query($conn, $getstatus);
                while ($getrow = mysqli_fetch_array($res)) {
                    $pres = $getrow["votedpres"];
                    $vpresi = $getrow["votedvpresi"];
                    $vprese = $getrow["votedvprese"];
                    $gensec = $getrow["votedgs"];
                    $depsec = $getrow["votedds"];
                    $trea = $getrow["votedtrea"];
                    $audi = $getrow["votedaudi"];
                    $piom = $getrow["votedpiom"];
                    $piof = $getrow["votedpiof"];
                    if ((($pres != "0") && ($vpresi != "0") && ($vprese != "0") && ($gensec != "0") && ($depsec != "0") && ($trea != "0") && ($audi != "0") && ($piom != "0") && ($piof != "0"))) {
                        $updatequery = "UPDATE studentvote set vstatus = 'Voted' WHERE sno = '$sno'";
                        $up = mysqli_query($conn, $updatequery);
                    }
                }
                header('Location: gensec.php');
                exit;
            }
        } else {
            header('Location: gensec.php');
            exit;
        }
    } else {
        header('Location: dashboard.php');
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/vote.css">
    <link rel="shortcut icon" href="/src/cict.png" type="image/x-icon/">
    <title>Vote Vice President - External</title>
</head>

<body>
    <script>
        function toggleMobileMenu(menu) {
            menu.classList.toggle('open');
        }
    </script>
    <header>
        <div class="top g-0 py-0">
            <div class="logo">
                <img src="/src/cict.png" class="icon">
            </div>
            <div class="name">
                <p class="schoolname">Taguig City University</p>
                <p class="webname">Computer Science Voting Portal</p>
            </div>
            <div id="hamburger-icon" onclick="toggleMobileMenu(this)">
                <div class="bar1"></div>
                <div class="bar2"></div>
                <div class="bar3"></div>
                <ul class="mobile-menu">
                    <li><a href="dashboard.php">Home</a></li>
                    <li><a href="president.php">President<?php if($bpres == 0){
                            echo '<span class="badge badge-light">Vote</span>';
                        } ?>
                    </span></a></li>
                    <li><a href="vpresi.php">VP - Internal<?php if($bvpresi == 0){
                            echo '<span class="badge badge-light">Vote</span>';
                        } ?>
                    </span></a></li>
                    <li><a href="vprese.php">VP - External<?php if($bvprese == 0){
                            echo '<span class="badge badge-light">Vote</span>';
                        } ?>
                    </span></a></li>
                    <li><a href="gensec.php">General Secretary<?php if($bdgs == 0){
                            echo '<span class="badge badge-light">Vote</span>';
                        } ?>
                    </span></a></li>
                    <li><a href="depsec.php">Deputy Secretary<?php if($bdds == 0){
                            echo '<span class="badge badge-light">Vote</span>';
                        } ?>
                    </span></a></li>
                    <li><a href="trea.php">Treasurer<?php if($btrea == 0){
                            echo '<span class="badge badge-light">Vote</span>';
                        } ?>
                    </span></a></li>
                    <li><a href="audi.php">Auditor<?php if($baudi == 0){
                            echo '<span class="badge badge-light">Vote</span>';
                        } ?>
                    </span></a></li>
                    <li><a href="piom.php">PIO - Male<?php if($bpiom == 0){
                            echo '<span class="badge badge-light">Vote</span>';
                        } ?>
                    </span></a></li>
                    <li><a href="piof.php">PIO - Female<?php if($bpiof == 0){
                            echo '<span class="badge badge-light">Vote</span>';
                        } ?>
                    </span></a></li>
                    <li><a href="report.php">Voted Candidates</a></li>
                    <li><a href="stats.php">Report</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>

    </header><br>
    <div class="text-center">
        <?php
        include('connection.php');
        $countquery = "SELECT * FROM candidate WHERE candidateposition = 'Vice President - External'";
        $countres = mysqli_query($conn, $countquery);
        while ($getrow = mysqli_fetch_array($countres)) {
            $cname = $getrow["candidatename"];
            $cpos = $getrow["candidateposition"];
            $cstno = $getrow["candidatestudentnumber"];
            $cpartylist = $getrow["candidatepartylist"];
            $imageurl = $getrow["candidatepicture"];
            echo    '<form method = "post">
                        <div class="row pb-3 ml-4 mr-0">
                            <div class="col-11 card text-center" style="width: 18rem;">
                                    <img src="src/candidate/Vice President - External/' . $imageurl . '" class="card-img-top py-3 rounded-circle" alt="...">
                                    <div class="card-body-lg py-0 px-0">
                                        <p class="card-text">' . $cname . '</p>
                                        <p class="text-secondary">' . $cpos . '</p>
                                        <p class="text-secondary">' . $cpartylist . '</p>
                                        <button class="btn btn-primary mb-2" type="submit" name = "votevprese" value = "' . $cstno . '" >Vote ' . $cname . ' </button>
                                    </div>
                                </div>
                            </div>
                        </form>';
        }
        ?>
    </div>
</body>


</html>