<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <title>Document</title>
</head>

<body>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <form method="post">
        <select class="form-select" name="mySelect" id="position" onchange="showSelectedValue()">
            <option value="President">President</option>
            <option value="Vice President - Internal">Vice President - Internal</option>
            <option value="Vice President - External">Vice President - External</option>
            <option value="General Secretary">General Secretary</option>
            <option value="Deputy Secretary">Deputy Secretary</option>
            <option value="Treasurer">Treasurer</option>
            <option value="Auditor">Auditor</option>
            <option value="Public Information Officer - Male">Public Information Officer - Male</option>
            <option value="Public Information Officer - Female">Public Information Officer - Female</option>
        </select>
    </form>
    <div id="selectedValue"></div>
    <div id="selectedText"></div>
    <canvas id="pos" width="250%" height="100%"></canvas>
    <script>
        const leadq = [];
        var pos;
        const socket = new WebSocket('ws://localhost:8080');

        socket.addEventListener('open', (event) => {
            console.log('Connected to WebSocket server');
        });

        socket.addEventListener('message', (event) => {
            const candidatesData = JSON.parse(event.data);
            console.log(pos);
            switch (pos) {
                case "President":
                    leadq.length = 0;
                    for (const obj of candidatesData.President) {
                        leadq.push({
                            name: obj.pres_name,
                            votes: obj.pres_votes
                        });
                    }
                    updateChart(pospie, leadq);
                    break;
                case "Vice President - Internal":
                    leadq.length = 0;
                    for (const obj of candidatesData.Vpresi) {
                        leadq.push({
                            name: obj.vpresi_name,
                            votes: obj.vpresi_votes
                        });
                    }
                    updateChart(pospie, leadq);
                    break;
                case "Vice President - External":
                    leadq.length = 0;
                    for (const obj of candidatesData.Vprese) {
                        leadq.push({
                            name: obj.vprese_name,
                            votes: obj.vprese_votes
                        });
                    }
                    updateChart(pospie, leadq);
                    break;
                case "General Secretary":
                    leadq.length = 0;
                    for (const obj of candidatesData.gensec) {
                        leadq.push({
                            name: obj.gensec_name,
                            votes: obj.gensec_votes
                        });
                    }
                    updateChart(pospie, leadq);
                    break;
                case "Deputy Secretary":
                    leadq.length = 0;
                    for (const obj of candidatesData.depsec) {
                        leadq.push({
                            name: obj.depsec_name,
                            votes: obj.depsec_votes
                        });
                    }
                    updateChart(pospie, leadq);
                    break;
                case "Treasurer":
                    leadq.length = 0;
                    for (const obj of candidatesData.trea) {
                        leadq.push({
                            name: obj.trea_name,
                            votes: obj.trea_votes
                        });
                    }
                    updateChart(pospie, leadq);
                    break;
                case "Auditor":
                    leadq.length = 0;
                    for (const obj of candidatesData.audi) {
                        leadq.push({
                            name: obj.audi_name,
                            votes: obj.audi_votes
                        });
                    }
                    updateChart(pospie, leadq);
                    break;
                case "Public Information Officer - Male":
                    leadq.length = 0;
                    for (const obj of candidatesData.piom) {
                        leadq.push({
                            name: obj.piom_name,
                            votes: obj.piom_votes
                        });
                    }
                    updateChart(pospie, leadq);
                    break;
                case "Public Information Officer - Female":
                    leadq.length = 0;
                    for (const obj of candidatesData.piof) {
                        leadq.push({
                            name: obj.piof_name,
                            votes: obj.piof_votes
                        });
                    }
                    updateChart(pospie, leadq);
                    break;

            }
            if (pos) {

            }

            if (pos) {

            }

            if (pos) {

            }

            if (pos) {

            }

            if (pos) {

            }

            if (pos) {

            }

            if (pos) {

            }

            if (pos) {

            }

            if (pos) {

            }
        });

        function updateChart(chart, data) {

            chart.data.labels = data.map(obj => obj.name);
            chart.data.datasets[0].data = data.map(obj => obj.votes);

            chart.update();
        }

        socket.addEventListener('close', (event) => {
            console.log('Disconnected from WebSocket server');
        });

        const lead = {
            labels: [
                '1st',
                '2nd',
                '3rd'
            ],
            datasets: [{
                label: 'Top 3 Leading Votes',
                data: [],
                backgroundColor: [
                    'rgb(255, 99, 132)',
                    'rgb(54, 162, 235)',
                    'rgb(255, 205, 86)'
                ],
                hoverOffset: 4
            }]
        };
        const configpos = {
            type: 'doughnut',
            data: lead,
        };
        const pospie = new Chart(document.getElementById('pos'), configpos);

        function showSelectedValue() {
            var selectElement = document.getElementById("position");
            var selectedValue = selectElement.value;
            var selectedText = selectElement.options[selectElement.selectedIndex].text;
            pos = selectedValue;
        }
    </script>
    <script>
    </script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
</body>

</html>