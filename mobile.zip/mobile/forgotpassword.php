<?php
include('connection.php');
session_start();
if (isset($_SESSION['stno'])) {
    header("Location: dashboard.php");
    exit;
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

if (isset($_POST['login'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/css/login.css">
    <link rel="shortcut icon" href="/src/cict.png" type="image/x-icon/">
    <title>Forgot password</title>
</head>

<body>
    <div class="top">
        <div class="logo">
            <img src="/src/cict.png" class="icon">
        </div>
        <div class="name">
            <p class="webname">Computer Science Voting Portal</p>
            <p class="schoolname">Taguig City University</p>
        </div>
    </div>
    <div>
        <form method="post">
            <button type="submit" name='login' class="home"><i class="fa-solid fa-arrow-left"></i> Back to Login</button>
        </form>
    </div>
    <div class="card shadow p-3 mb-5 bg-white rounded">
        <h5 class="card-header">CS Voting System</h5>
        <div class="card-body">
            <h2 class="card-title text-center">Forgot Password</h2>
            <form method="post" class="forgotform">
                <div class="logform m-auto">

                    <p>Email Address</p>
                    <input type="email" name="smail" class="logtext">
                    <div class="btns">
                        <button type="submit" name='send' class="login">Send email</button>

                    </div>
                    <br>
                    <?php
                    if (!empty($_POST['smail'])) {
                        if (isset($_POST['send'])) {
                            $smail = $_POST['smail'];
                            $searchemail = "Select studentemail from studentlist where studentemail = '$smail'";

                            $search = mysqli_query($conn, $searchemail);
                            if (mysqli_num_rows($search) == 1) {
                                $mail = new PHPMailer(true);
                                try {
                                    $mail->isSMTP();
                                    $mail->Host       = 'smtp.gmail.com';
                                    $mail->SMTPAuth   = true;
                                    $mail->Username   = 'kobe.suarez18@gmail.com';
                                    $mail->Password   = 'ookrlbxnpfpbfwza';
                                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
                                    $mail->Port       = 465;

                                    $mail->setFrom('kobe.suarez18@gmail.com');
                                    $mail->addAddress($_POST['smail']);
                                    $length = 10;
                                    $keyspace = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

                                    $str = '';
                                    $max = mb_strlen($keyspace, '8bit') - 1;
                                    for ($i = 0; $i < $length; ++$i) {
                                        $str .= $keyspace[random_int(0, $max)];
                                    }
                                    //Content
                                    $mail->isHTML(true);
                                    $mail->Subject = 'New password';
                                    $mail->Body    = "Your new password for your account in Taguig City University
                            CICT Voting System is: {$str}. <a href='http://localhost:3000/login.php/' >Click here</a> to Login your account";

                                    $mail->send();
                                    $reset = "UPDATE studentlist SET studentpassword = '$str' where studentemail = '$smail'";
                                    mysqli_query($conn, $reset);

                                    echo "<p class = 'text-success'><b>Email sent.</b></p>";
                                } catch (Exception $e) {
                                    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
                                }
                            } else {
                                echo "<p class = 'text-danger'><b>Email already sent!</b></p>";
                            }
                        } else {
                            echo "<p class = 'text-danger'><b>Email Address not found!</b></p>";
                        }
                    }

                    ?>
                </div>

            </form>

        </div>
    </div>


</body>

</html>