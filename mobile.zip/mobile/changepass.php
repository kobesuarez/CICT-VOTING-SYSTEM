<?php
include('connection.php');
session_start();

if (isset($_POST['home'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/css/login.css">
    <link rel="shortcut icon" href="/src/cict.png" type="image/x-icon/">
    <title>Log in</title>
</head>

<body>
    <div class="top">
        <div class="logo">
            <img src="/src/cict.png" class="icon">
        </div>
        <div class="name">
            <p class="webname">Computer Science Voting Portal</p>
            <p class="schoolname">Taguig City University</p>
        </div>
    </div>
    <div>
        <form method="post">
            <button type="submit" name='home' class="home"><i class="fa-solid fa-arrow-left"></i> Go to Login</button>

        </form>
    </div>

    <form method="post">
        <h2 class="ml-4">Change password</h2>
        <div class="logform m-auto">

            <p>Student number</p>
            <input type="text" name="sno" class="logtext">
            <button type ="button" name = "search" class = "btn btn-primary py-1 ml-1" style = "width: 40%;">Search</button>
            <?php 
            if(isset($_POST['search'])){
                $stno = $_POST['sno'];
                $search = "SELECT request_pass from studentlist WHERE studentnumber ='$stno'";
                if (mysqli_num_rows(mysqli_query($conn, $search)) == 1) {
                    
                }else{
                    echo "<p class ='text-danger'>Account not found!</p>";
                }
            }
            
            ?>
        </div>

    </form>
</body>

</html>