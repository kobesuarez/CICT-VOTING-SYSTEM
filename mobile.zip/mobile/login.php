<?php
include('connection.php');
session_start();
if (isset($_SESSION['stno'])){
    header("Location: dashboard.php");
    exit;
}



if (isset($_POST['forgot'])) {
    header("Location: forgotpassword.php");
}

if (isset($_POST['home'])) {
    header("Location: Dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/css/login.css">
    <link rel="shortcut icon" href="/src/cict.png" type="image/x-icon/">
    <title>Log in</title>
</head>

<body>
    <div class="top">
        <div class="logo">
            <img src="/src/cict.png" class="icon">
        </div>
        <div class="name">
            <p class="webname">Computer Science Voting Portal</p>
            <p class="schoolname">Taguig City University</p>
        </div>
    </div>
    <div>
        <form method="post">
            <button type="submit" name='home' class="home"><i class="fa-solid fa-arrow-left"></i> See Current Partylist</button>

        </form>
    </div>
    <div class="card shadow p-3 mb-5 bg-white rounded">
        <h5 class="card-header">CS Voting System</h5>
        <div class="card-body">
            <h2 class="card-title text-center">Login</h2>
            <form method="post">
                <div class="logform m-auto">
                    <p>Student number</p>
                    <input type="text" name="sno" class="logtext" value="<?php echo (isset($_COOKIE['sno']) ? $_COOKIE['sno'] : ""); ?>"><br>
                    <p>Password</p>

                    <input type="password" name="pword" class="logtext" value="<?php echo (isset($_COOKIE['pword']) ? $_COOKIE['pword'] : ""); ?>">
                    <?php
                    if (isset($_POST['login'])) {
                        if (empty($_POST['sno']) || empty($_POST['pword'])) {
                            echo '<p class = "text-danger"><b>Fields must not be blanks!</b></p>';
                        } else {
                            $studentnumber = $_POST['sno'];
                            $studentpass = $_POST['pword'];
                            $loginquery = "SELECT * FROM studentlist WHERE studentnumber = '$studentnumber' AND studentpassword = '$studentpass'";
                            $res = mysqli_query($conn, $loginquery);
                            if (mysqli_num_rows($res) == 1) {
                                $data = mysqli_fetch_array($res);
                                $stno = $data['studentnumber'];

                                $_SESSION['stno'] = $stno;
                                if (!empty($_POST["remember"])) {
                                    setcookie('sno', $_POST['sno'], time() + 3600);
                                    setcookie('pword', $_POST['pword'], time() + 3600);
                                    header("Location: dashboard.php");
                                    exit;
                                } else {
                                    if (isset($_COOKIE['sno']) && isset($_COOKIE['pword'])) {
                                        setcookie('sno', '', time() - 3600);
                                        setcookie('pword', '', time() - 3600);
                                        header("Location: dashboard.php");
                                        exit;
                                    }
                                    header("Location: dashboard.php");
                                    exit;
                                }
                            } else {
                                echo '<p class = "text-danger"><b>Invalid Username or password.</b></p>';
                            }
                        }
                    }
                    ?>
                    <p><input type="checkbox" name="remember" <?php
                                                                echo (isset($_COOKIE['sno']) && isset($_COOKIE['pword']) ? 'checked' : '');
                                                                ?> /> Remember me<br><br>
                    <div class="btns">
                        <button type="submit" name='login' class="login">Log In</button>
                    </div>
                    <a name="forgot" href="forgotpassword.php" class="d-flex justify-content-center" style="color: black">Forgot password?</a>
                </div>
            </form>
        </div>
    </div>
</body>

</html>