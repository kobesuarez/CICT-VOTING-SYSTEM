<?php
include('checkvote.php');

include('Voting System\php\datevalidation.php');
if (!empty($exp_date)) {
    $newDate = date("m/d/y", strtotime($exp_date));
    $exp = $newDate;
    $today_date = date('m/d/y');
    $td = strtotime($today_date);
    $ed = strtotime($exp);
    if ($td <= $ed) {
        $diff = $td - $ed;
        $days = abs(floor($diff / (60 * 60 * 24)));
        $datemess = "Voting Started! Remaining days:";
        $alert = "alert alert-info";
    } else {
        $datemess = "The schedule for voting is already done!";
        $alert = "alert alert-danger";
        header("Location: stats.php");
    }
} else {
    $datemess = "Schedule to be Announce";
    $alert = "alert alert-primary";
    header("Location: Dashboard.php");
}
if (isset($_SESSION['stno'])) {
    $sno = $_SESSION['stno'];
    if ($piom == 0) {
            if (isset($_POST['votepiom'])) {
                $id = $_POST['votepiom'];
                $votequery = "SELECT votes FROM piom WHERE piom_no = '$id'";
                $vote = mysqli_query($conn, $votequery);
                $data = mysqli_fetch_array($vote);
                $getvote = $data['votes'];
                $getvote = $getvote + 1;
                $updatevote = "UPDATE piom SET votes = '$getvote' WHERE piom_no = '$id'";
                mysqli_query($conn, $updatevote);
                $updatestudent = "UPDATE studentvote SET votedpiom = '$id' WHERE sno = '$sno'";
                mysqli_query($conn, $updatestudent);
                $getstatus = "SELECT * from studentvote WHERE sno = '$sno'";
                $res = mysqli_query($conn, $getstatus);
                while ($getrow = mysqli_fetch_array($res)) {
                    $pres = $getrow["votedpres"];
                    $vpresi = $getrow["votedvpresi"];
                    $vprese = $getrow["votedvprese"];
                    $gensec = $getrow["votedgs"];
                    $depsec = $getrow["votedds"];
                    $trea = $getrow["votedtrea"];
                    $audi = $getrow["votedaudi"];
                    $piom = $getrow["votedpiom"];
                    $piof = $getrow["votedpiof"];
                    if ((($pres != "0") && ($vpresi != "0") && ($vprese != "0") && ($gensec != "0") && ($depsec != "0") && ($trea != "0") && ($audi != "0") && ($piom != "0") && ($piof != "0"))) {
                        $updatequery = "UPDATE studentvote set vstatus = 'Voted' WHERE sno = '$sno'";
                        $up = mysqli_query($conn, $updatequery);
                    }
                }
                header('Location: piof.php');
                exit;
            }
        } else {
            header('Location: piof.php');
            exit;
        }
    } else {
        header('Location: dashboard.php');
        exit;
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="/css/vote.css">
    <link rel="shortcut icon" href="/src/cict.png" type="image/x-icon/">
    <title>Vote Public Information Officer - Male</title>
</head>

<body>
    <header id="navbar">
        <nav class="navbar-container container">
            <div class="home-link">
                <img src="/src/cict.png" class="navbar-logo" />
                Taguig City University<br />
                Computer Science Voting Portal
            </div>
            <button type="button" id="navbar-toggle" aria-controls="navbar-menu" aria-label="Toggle menu" aria-expanded="false">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <div id="navbar-menu" aria-labelledby="navbar-toggle">
                <ul class="navbar-links">
                    <?php
                    if (!isset($_SESSION['stno'])) {
                        echo   '<li class="navbar-item"><a class="navbar-link" href="dashboard.php">Home</a></li>
								<li class="navbar-item"><a class="navbar-link" href="login.php">Login</a></li>
								<li class="navbar-item"><a class="navbar-link" href="stats.php">Report</a></li>';
                    } else {
                        echo   '<li class="navbar-item"><a class="navbar-link" href="dashboard.php">Home</a></li>
								<div class="dropdown">
									<button class="navbar-link dropbtn" onclick="myFunction()">Vote </br>
										<i class="fa fa-caret-down"> </i>
									</button>
									<div class="dropdown-content" id="myDropdown">
										<a class="navbar-link" href="president.php">President</a>
										<a class="navbar-link" href="vpresi.php">VP - Internal</a>
										<a class="navbar-link" href="vprese.php">VP - External</a>
										<a class="navbar-link" href="gensec.php">Public Information Officer - Male</a>
										<a class="navbar-link" href="depsec.php">Deputy Secretary</a>
										<a class="navbar-link" href="trea.php">Treasurer</a>
										<a class="navbar-link" href="audi.php">Auditor</a>
										<a class="navbar-link" href="piom.php">PIO - Male</a>
										<a class="navbar-link" href="piof.php">PIO - Female</a>
									</div>
								</div>
								<li class="navbar-item"><a class="navbar-link" href="report.php">Voted</a></li>
								<li class="navbar-item"><a class="navbar-link" href="stats.php">Report</a></li>
								<li class="navbar-item"><a class="navbar-link" href="logout.php">Logout</a></li>';
                    }

                    echo '<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>';
                    echo '<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>';
                    ?>
                </ul>
            </div>

        </nav>
    </header><br>
    <div class="cont">
        <br>
        <h2 class="text-center">Public Information Officer - Male</h2>
        <div class="pb-3">
            <?php
            include('connection.php');
            $countquery = "SELECT * FROM candidate WHERE candidateposition = 'Public Information Officer - Male'";
            $countres = mysqli_query($conn, $countquery);
            while ($getrow = mysqli_fetch_array($countres)) {
                $cname = $getrow["candidatename"];
                $cstno = $getrow["candidatestudentnumber"];
                $cpos = $getrow["candidateposition"];
                $cpartylist = $getrow["candidatepartylist"];
                $imageurl = $getrow["candidatepicture"];
                echo    '<form method = "post">
                                <div class="col-12 card text-center" style="width: 18rem;">
                                        <img src="src/candidate/Public Information Officer - Male/' . $imageurl . '" class="card-img-top py-3 rounded-circle" alt="...">
                                        <div class="card-body py-0 px-0">
                                            <p class="card-text">' . $cname . '</p>
                                            <p class="text-secondary">' . $cpos . '</p>
                                            <p class="text-secondary">' . $cpartylist . '</p>
                                            <button class="btn btn-primary mb-2" type="submit" name = "votepres" value = "' . $cstno . '" >Vote ' . $cname . ' </button>
                                        </div>
                                    </div>
                            </form>';
            }
            ?>
        </div>
    </div>
    <br>
    <script>
        function myFunction() {
            document.getElementById("myDropdown").classList.toggle("show");
        }

        window.onclick = function(e) {
            if (!e.target.matches('.dropbtn')) {
                var myDropdown = document.getElementById("myDropdown");
                if (myDropdown.classList.contains('show')) {
                    myDropdown.classList.remove('show');
                }
            }
        }
        const navbarToggle = navbar.querySelector("#navbar-toggle");
        const navbarMenu = document.querySelector("#navbar-menu");
        const navbarLinksContainer = navbarMenu.querySelector(".navbar-links");
        let isNavbarExpanded =
            navbarToggle.getAttribute("aria-expanded") === "true";

        const toggleNavbarVisibility = () => {
            isNavbarExpanded = !isNavbarExpanded;
            navbarToggle.setAttribute("aria-expanded", isNavbarExpanded);
        };

        navbarToggle.addEventListener("click", toggleNavbarVisibility);

        navbarLinksContainer.addEventListener("click", (e) =>
            e.stopPropagation()
        );
        navbarMenu.addEventListener("click", toggleNavbarVisibility);
    </script>
</body>


</html>