<?php
include('connection.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (isset($_SESSION['stno'])) {
    $sno = $_SESSION['stno'];
    $searchquery = "SELECT * FROM studentvote where sno = '$sno'";
    $res = mysqli_query($conn, $searchquery);
    if (mysqli_num_rows($res) == 1) {
        $data = mysqli_fetch_array($res);
        $pres = $data['votedpres'];
        $vpresi = $data['votedvpresi'];
        $vprese = $data['votedvprese'];
        $gensec = $data['votedgs'];
        $depsec = $data['votedds'];
        $trea = $data['votedtrea'];
        $audi = $data['votedaudi'];
        $piom = $data['votedpiom'];
        $piof = $data['votedpiof'];
    }
} else {
    header('Location: dashboard.php');
    exit;
}
include('Voting System\php\datevalidation.php');
if (!empty($exp_date)) {
    $newDate = date("m/d/y", strtotime($exp_date));
    $exp = $newDate;
    $today_date = date('m/d/y');
    $td = strtotime($today_date);
    $ed = strtotime($exp);
    if ($td <= $ed) {
        $diff = $td - $ed;
        $days = abs(floor($diff / (60 * 60 * 24)));
        $datemess = "Voting Started! Remaining days:";
        $alert = "alert alert-info";
    } else {
        $datemess = "The schedule for voting is already done!";
        $alert = "alert alert-danger";
    }
} else {
    $datemess = "Schedule to be Announce";
    $alert = "alert alert-primary";
}
$getstatus = "SELECT * from studentvote WHERE sno = '$sno'";
$res = mysqli_query($conn, $getstatus);
while ($getrow = mysqli_fetch_array($res)) {
    $pres = $getrow["votedpres"];
    $vpresi = $getrow["votedvpresi"];
    $vprese = $getrow["votedvprese"];
    $gensec = $getrow["votedgs"];
    $depsec = $getrow["votedds"];
    $trea = $getrow["votedtrea"];
    $audi = $getrow["votedaudi"];
    $piom = $getrow["votedpiom"];
    $piof = $getrow["votedpiof"];
    if (!(($pres == "0") && ($vpresi == "0") && ($vprese == "0") && ($gensec == "0") && ($depsec == "0") && ($trea == "0") && ($audi == "0") && ($piom == "0") && ($piof == "0"))) {
        $updatequery = "UPDATE studentvote set vstatus = 'Voted' WHERE sno = '$sno'";
        $up = mysqli_query($conn, $getstatus);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/vote.css">
    <link rel="shortcut icon" href="/src/cict.png" type="image/x-icon/">
    <title>Report</title>
</head>

<body>
    <script>
        function toggleMobileMenu(menu) {
            menu.classList.toggle('open');
        }
    </script>
    <header>
        <div class="top g-0 py-0">
            <div class="logo">
                <img src="/src/cict.png" class="icon">
            </div>
            <div class="name">
                <p class="schoolname">Taguig City University</p>
                <p class="webname">Computer Science Voting Portal</p>
            </div>
            <div id="hamburger-icon" onclick="toggleMobileMenu(this)">
                <div class="bar1"></div>
                <div class="bar2"></div>
                <div class="bar3"></div>
                <ul class="mobile-menu">
                    <li><a href="dashboard.php">Home</a></li>
                    <li><a href="president.php">President</a></li>
                    <li><a href="vpresi.php">VP - Internal</a></li>
                    <li><a href="vprese.php">VP - External</a></li>
                    <li><a href="gensec.php">General Secretary</a></li>
                    <li><a href="depsec.php">Deputy Secretary</a></li>
                    <li><a href="trea.php">Treasurer</a></li>
                    <li><a href="audi.php">Auditor</a></li>
                    <li><a href="piom.php">PIO - Male</a></li>
                    <li><a href="piof.php">PIO - Female</a></li>
                    <li><a href="report.php">Voted Candidates</a></li>
                    <li><a href="stats.php">Report</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>

    </header><br>
    <div class="<?php echo $alert; ?>" role="alert">
        <h2 class="text-center"><?php echo $datemess; ?></h2>
        <h2 class="text-center"><?php if(!empty($td ) && !empty($ed)) if ($td <= $ed) echo $days . " days"; ?></h2>
    </div>
    <div>
        <?php
        include('connection.php');
        $countquery = "SELECT * FROM candidate WHERE candidatestudentnumber = '$pres'";
        $countres = mysqli_query($conn, $countquery);
        while ($getrow = mysqli_fetch_array($countres)) {
            $cname = $getrow["candidatename"];
            $cpos = $getrow["candidateposition"];
            $cstno = $getrow["candidatestudentnumber"];
            $cpartylist = $getrow["candidatepartylist"];
            $imageurl = $getrow["candidatepicture"];
            echo    '<div class="row pb-3 ml-5 mr-0">
                    <div class="col-11 card text-center" style="width: 18rem;">
                            <img src="src/candidate/President/' . $imageurl . '" class="card-img-top py-3 rounded-circle" alt="...">
                             <div class="card-body py-0 px-0">
                                <p class="card-text">' . $cname . '</p>
                                <p class="text-secondary">' . $pres . '</p>
                                <p class="text-secondary">' . $cpos . '</p>
                                <p class="text-secondary">' . $cpartylist . '</p>
                            </div>
                        </div>
                    </div>';
        }
        ?>
    </div>

    <div>
        <?php
        include('connection.php');
        $countquery = "SELECT * FROM candidate WHERE candidatestudentnumber = '$vpresi'";
        $countres = mysqli_query($conn, $countquery);
        while ($getrow = mysqli_fetch_array($countres)) {
            $cname = $getrow["candidatename"];
            $cpos = $getrow["candidateposition"];
            $cstno = $getrow["candidatestudentnumber"];
            $cpartylist = $getrow["candidatepartylist"];
            $imageurl = $getrow["candidatepicture"];
            echo    '<div class="row pb-3 ml-5 mr-0">
                    <div class="col-11 card text-center" style="width: 18rem;">
                            <img src="src/candidate/Vice President - Internal/' . $imageurl . '" class="card-img-top py-3 rounded-circle" alt="...">
                             <div class="card-body py-0 px-0">
                                <p class="card-text">' . $cname . '</p>
                                <p class="text-secondary">' . $vpresi . '</p>
                                <p class="text-secondary">' . $cpos . '</p>
                                <p class="text-secondary">' . $cpartylist . '</p>
                                
                            </div>
                        </div>
                    </div>';
        }
        ?>
    </div>

    <div>
        <?php
        include('connection.php');
        $countquery = "SELECT * FROM candidate WHERE candidatestudentnumber = '$vprese'";
        $countres = mysqli_query($conn, $countquery);
        while ($getrow = mysqli_fetch_array($countres)) {
            $cname = $getrow["candidatename"];
            $cpos = $getrow["candidateposition"];
            $cstno = $getrow["candidatestudentnumber"];
            $cpartylist = $getrow["candidatepartylist"];
            $imageurl = $getrow["candidatepicture"];
            echo    '<div class="row pb-3 ml-5 mr-0">
                    <div class="col-11 card text-center" style="width: 18rem;">
                            <img src="src/candidate/Vice President - External/' . $imageurl . '" class="card-img-top py-3 rounded-circle" alt="...">
                             <div class="card-body py-0 px-0">
                                <p class="card-text">' . $cname . '</p>
                                <p class="text-secondary">' . $vprese . '</p>
                                <p class="text-secondary">' . $cpos . '</p>
                                <p class="text-secondary">' . $cpartylist . '</p>
                            </div>
                        </div>
                    </div>';
        }
        ?>
    </div>

    <div>
        <?php
        include('connection.php');
        $countquery = "SELECT * FROM candidate WHERE candidatestudentnumber = '$gensec'";
        $countres = mysqli_query($conn, $countquery);
        while ($getrow = mysqli_fetch_array($countres)) {
            $cname = $getrow["candidatename"];
            $cpos = $getrow["candidateposition"];
            $cstno = $getrow["candidatestudentnumber"];
            $cpartylist = $getrow["candidatepartylist"];
            $imageurl = $getrow["candidatepicture"];
            echo    '<div class="row pb-3 ml-5 mr-0">
                    <div class="col-11 card text-center" style="width: 18rem;">
                            <img src="src/candidate/General Secretary/' . $imageurl . '" class="card-img-top py-3 rounded-circle" alt="...">
                             <div class="card-body py-0 px-0">
                                <p class="card-text">' . $cname . '</p>
                                <p class="text-secondary">' . $gensec . '</p>
                                <p class="text-secondary">' . $cpos . '</p>
                                <p class="text-secondary">' . $cpartylist . '</p>
                            </div>
                        </div>
                    </div>';
        }
        ?>
    </div>
    <div>
        <?php
        include('connection.php');
        $countquery = "SELECT * FROM candidate WHERE candidatestudentnumber = '$depsec'";
        $countres = mysqli_query($conn, $countquery);
        while ($getrow = mysqli_fetch_array($countres)) {
            $cname = $getrow["candidatename"];
            $cpos = $getrow["candidateposition"];
            $cstno = $getrow["candidatestudentnumber"];
            $cpartylist = $getrow["candidatepartylist"];
            $imageurl = $getrow["candidatepicture"];
            echo    '<div class="row pb-3 ml-5 mr-0">
                    <div class="col-11 card text-center" style="width: 18rem;">
                            <img src="src/candidate/Deputy Secretary/' . $imageurl . '" class="card-img-top py-3 rounded-circle" alt="...">
                             <div class="card-body py-0 px-0">
                                <p class="card-text">' . $cname . '</p>
                                <p class="text-secondary">' . $depsec . '</p>
                                <p class="text-secondary">' . $cpos . '</p>
                                <p class="text-secondary">' . $cpartylist . '</p>
                            </div>
                        </div>
                    </div>';
        }
        ?>
    </div>
    <div>
        <?php
        include('connection.php');
        $countquery = "SELECT * FROM candidate WHERE candidatestudentnumber = '$trea'";
        $countres = mysqli_query($conn, $countquery);
        while ($getrow = mysqli_fetch_array($countres)) {
            $cname = $getrow["candidatename"];
            $cpos = $getrow["candidateposition"];
            $cstno = $getrow["candidatestudentnumber"];
            $cpartylist = $getrow["candidatepartylist"];
            $imageurl = $getrow["candidatepicture"];
            echo    '<div class="row pb-3 ml-5 mr-0">
                    <div class="col-11 card text-center" style="width: 18rem;">
                            <img src="src/candidate/Treasurer/' . $imageurl . '" class="card-img-top py-3 rounded-circle" alt="...">
                             <div class="card-body py-0 px-0">
                                <p class="card-text">' . $cname . '</p>
                                <p class="text-secondary">' . $trea . '</p>
                                <p class="text-secondary">' . $cpos . '</p>
                                <p class="text-secondary">' . $cpartylist . '</p>
                            </div>
                        </div>
                    </div>';
        }
        ?>
    </div>

    <div>
        <?php
        include('connection.php');
        $countquery = "SELECT * FROM candidate WHERE candidatestudentnumber = '$audi'";
        $countres = mysqli_query($conn, $countquery);
        while ($getrow = mysqli_fetch_array($countres)) {
            $cname = $getrow["candidatename"];
            $cpos = $getrow["candidateposition"];
            $cstno = $getrow["candidatestudentnumber"];
            $cpartylist = $getrow["candidatepartylist"];
            $imageurl = $getrow["candidatepicture"];
            echo    '<div class="row pb-3 ml-5 mr-0">
                    <div class="col-11 card text-center" style="width: 18rem;">
                            <img src="src/candidate/Auditor/' . $imageurl . '" class="card-img-top py-3 rounded-circle" alt="...">
                             <div class="card-body py-0 px-0">
                                <p class="card-text">' . $cname . '</p>
                                <p class="text-secondary">' . $audi . '</p>
                                <p class="text-secondary">' . $cpos . '</p>
                                <p class="text-secondary">' . $cpartylist . '</p>
                            </div>
                        </div>
                    </div>';
        }
        ?>
    </div>
    <div>
        <?php
        include('connection.php');
        $countquery = "SELECT * FROM candidate WHERE candidatestudentnumber = '$piom'";
        $countres = mysqli_query($conn, $countquery);
        while ($getrow = mysqli_fetch_array($countres)) {
            $cname = $getrow["candidatename"];
            $cpos = $getrow["candidateposition"];
            $cstno = $getrow["candidatestudentnumber"];
            $cpartylist = $getrow["candidatepartylist"];
            $imageurl = $getrow["candidatepicture"];
            echo    '<div class="row pb-3 ml-5 mr-0">
                    <div class="col-11 card text-center" style="width: 18rem;">
                            <img src="src/candidate/Public Information Officer - Male/' . $imageurl . '" class="card-img-top py-3 rounded-circle" alt="...">
                             <div class="card-body py-0 px-0">
                                <p class="card-text">' . $cname . '</p>
                                <p class="text-secondary">' . $piom . '</p>
                                <p class="text-secondary">' . $cpos . '</p>
                                <p class="text-secondary">' . $cpartylist . '</p>
                            </div>
                        </div>
                    </div>';
        }
        ?>
    </div>
    <div>
        <?php
        include('connection.php');
        $countquery = "SELECT * FROM candidate WHERE candidatestudentnumber = '$piof'";
        $countres = mysqli_query($conn, $countquery);
        while ($getrow = mysqli_fetch_array($countres)) {
            $cname = $getrow["candidatename"];
            $cpos = $getrow["candidateposition"];
            $cstno = $getrow["candidatestudentnumber"];
            $cpartylist = $getrow["candidatepartylist"];
            $imageurl = $getrow["candidatepicture"];
            echo    '<div class="row pb-3 ml-5 mr-0">
                    <div class="col-11 card text-center" style="width: 18rem;">
                            <img src="src/candidate/Public Information Officer - Female/' . $imageurl . '" class="card-img-top py-3 rounded-circle" alt="...">
                             <div class="card-body py-0 px-0">
                                <p class="card-text">' . $cname . '</p>
                                <p class="text-secondary">' . $piof . '</p>
                                <p class="text-secondary">' . $cpos . '</p>
                                <p class="text-secondary">' . $cpartylist . '</p>
                            </div>
                        </div>
                    </div>';
        }
        ?>
    </div>
</body>

</html>