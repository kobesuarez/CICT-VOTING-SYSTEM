<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include('Voting System\php\datevalidation.php');
if (!empty($exp_date)) {
    $newDate = date("m/d/y", strtotime($exp_date));
    $exp = $newDate;
    $today_date = date('m/d/y');
    $td = strtotime($today_date);
    $ed = strtotime($exp);
    if ($td <= $ed) {
        $diff = $td - $ed;
        $days = abs(floor($diff / (60 * 60 * 24)));
        $datemess = "Voting Started! Remaining days:";
        $alert = "alert alert-info";
    } else {
        $datemess = "The schedule for voting is already done!";
        $alert = "alert alert-danger";
    }
} else {
    $datemess = "Schedule to be Announce";
    $alert = "alert alert-primary";
}

if (isset($_SESSION['stno']))
    $sno = $_SESSION['stno'];
include('checkvote.php');

$searchquery = "SELECT * FROM current";
$res = mysqli_query($conn, $searchquery);
if (mysqli_num_rows($res) == 1) {
    $data = mysqli_fetch_array($res);
    $cpres = $data['pres'];
    $cvpresi = $data['vpresi'];
    $cvprese = $data['vprese'];
    $cgensec = $data['gensec'];
    $cdepsec = $data['depsec'];
    $ctrea = $data['trea'];
    $caudi = $data['audi'];
    $cpiom = $data['piom'];
    $cpiof = $data['piof'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/vote.css">
    <link rel="shortcut icon" href="/src/cict.png" type="image/x-icon/">
    <title>Dashboard</title>
</head>

<body>
    <script>
        function toggleMobileMenu(menu) {
            menu.classList.toggle('open');
        }
    </script>
    <header>
        <div class="top g-0 py-0">
            <div class="logo">
                <img src="/src/cict.png" class="icon">
            </div>
            <div class="name">
                <p class="schoolname">Taguig City University</p>
                <p class="webname">Computer Science Voting Portal</p>
            </div>
            <?php
            if (!isset($_SESSION['stno'])) {
                echo    '<div id="hamburger-icon" onclick="toggleMobileMenu(this)">
                            <div class="bar1"></div>
                            <div class="bar2"></div>
                            <div class="bar3"></div>
                                <ul class="mobile-menu h-25 g-0">
                                <li><a href="dashboard.php">Home</a></li>
                                <li><a href="login.php">Login</a></li>
                                <li><a href="stats.php">Report</a></li>
                            </ul>
                        </div>';
            } else {
                echo    '<div id="hamburger-icon" onclick="toggleMobileMenu(this)">
                            <div class="bar1"></div>
                            <div class="bar2"></div>
                            <div class="bar3"></div>
                            <ul class="mobile-menu">
                                <li><a href="dashboard.php">Home</a></li>
                                <li>
                                    <a href="president.php">
                                        President 
                                    </a>
                                </li>
                            <li><a href="vpresi.php">VP - Internal
                            </a></li>
                            <li><a href="vprese.php">VP - External
                            </a></li>
                            <li><a href="gensec.php">General Secretary
                            </a></li>
                            <li><a href="depsec.php">Deputy Secretary
                            </a></li>
                            <li><a href="trea.php">Treasurer
                            </a></li>
                            <li><a href="audi.php">Auditor
                            </a></li>
                            <li><a href="piom.php">PIO - Male
                            </a></li>
                            <li><a href="piof.php">PIO - Female
                            </a></li>
                            <li><a href="report.php">Voted Candidates</a></li>
                                <li><a href="stats.php">Report</a></li>
                                
                                <li><a href="logout.php">Logout</a></li>
                            </ul>
                        </div>';
            }
            ?>
        </div>

    </header><br>
    <div class="<?php echo $alert; ?>" role="alert">
        <h2 class="text-center"><?php echo $datemess; ?></h2>
        <h2 class="text-center"><?php if(!empty($td ) && !empty($ed)) if ($td <= $ed) echo $days . " days"; ?></h2>
    </div>

    <h2 class="text-center">Current Partylist</h2>
    <div class="current px-4 py-3">
        <div class="row justify-content-around py-3">
            <div class="col-5 card text-center" style="width: 18rem;">
                <img src="/src/currentpartylist/President.jpg" class="card-img-top py-3 rounded-circle" alt="...">
                <div class="card-body py-0 px-0">
                    <p class="card-text"><?php echo $cpres; ?></p>
                    <p class="text-secondary"><?php echo "President"; ?></p>
                </div>
            </div>
        </div>

        <div class="row justify-content-around py-3">
            <div class="col-5 card text-center" style="width: 18rem;">
                <img src="/src/currentpartylist/Vice President - Internal.jpg" class="card-img-top py-3 rounded-circle" alt="...">
                <div class="card-body py-0 px-0">
                    <p class="card-text"><?php echo $cvpresi; ?></p>
                    <p class="text-secondary"><?php echo "Vice President - Internal"; ?></p>
                </div>
            </div>

            <div class="col-5 card text-center" style="width: 18rem;">
                <img src="/src/currentpartylist/Vice President - External.png" class="card-img-top py-3 rounded-circle" alt="...">
                <div class="card-body py-0 px-0">
                    <p class="card-text"><?php echo $cvprese; ?></p>
                    <p class="text-secondary"><?php echo "Vice President - External"; ?></p>
                </div>
            </div>
        </div>

        <div class="row justify-content-around py-3">
            <div class="col-5 card text-center" style="width: 18rem;">
                <img src="/src/currentpartylist/General Secretary.png" class="card-img-top py-3 rounded-circle" alt="...">
                <div class="card-body py-0 px-0">
                    <p class="card-text"><?php echo $cgensec; ?></p>
                    <p class="text-secondary"><?php echo "General Secretary"; ?></p>
                </div>
            </div>

            <div class="col-5 card text-center" style="width: 18rem;">
                <img src="/src/currentpartylist/Deputy Secretary.jpg" class="card-img-top py-3 rounded-circle" alt="...">
                <div class="card-body py-0 px-0">
                    <p class="card-text"><?php echo $cdepsec; ?></p>
                    <p class="text-secondary"><?php echo "Deputy Secretary"; ?></p>
                </div>
            </div>
        </div>

        <div class="row justify-content-around py-3">
            <div class="col-5 card text-center" style="width: 18rem;">
                <img src="/src/currentpartylist/Treasurer.jpg" class="card-img-top py-3 rounded-circle" alt="...">
                <div class="card-body py-0 px-0">
                    <p class="card-text"><?php echo $ctrea; ?></p>
                    <p class="text-secondary"><?php echo "Treasurer"; ?></p>
                </div>
            </div>

            <div class="col-5 card text-center" style="width: 18rem;">
                <img src="/src/currentpartylist/Auditor.jpeg" class="card-img-top py-3 rounded-circle" alt="...">
                <div class="card-body py-0 px-0">
                    <p class="card-text"><?php echo $caudi; ?></p>
                    <p class="text-secondary"><?php echo "Auditor"; ?></p>
                </div>
            </div>
        </div>

        <div class="row justify-content-around py-3">
            <div class="col-5 card text-center" style="width: 18rem;">
                <img src="/src/currentpartylist/Public Information Officer - Male.JPG" class="card-img-top py-3 rounded-circle" alt="...">
                <div class="card-body py-0 px-0">
                    <p class="card-text"><?php echo $cpiom; ?></p>
                    <p class="text-secondary"><?php echo "Public Information Officer - Male"; ?></p>
                </div>
            </div>

            <div class="col-5 card text-center" style="width: 18rem;">
                <img src="/src/currentpartylist/Public Information Officer - Female.jpg" class="card-img-top py-3 rounded-circle" alt="...">
                <div class="card-body py-0 px-0">
                    <p class="card-text"><?php echo $cpiof; ?></p>
                    <p class="text-secondary"><?php echo "Public Information Officer - Female"; ?></p>
                </div>
            </div>
        </div>
    </div>

    <script>
        function popup() {
            var x = document.getElementById("myLinks");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }
    </script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>